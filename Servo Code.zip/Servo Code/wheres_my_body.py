import subprocess
import time
from time import sleep

subprocess.Popen(["python", 'eyes_wheres_my_body.py'])
subprocess.Popen(["python", 'neck_wheres_my_body.py'])
time.sleep(3)
subprocess.Popen(["python", 'expression_sad_longer.py'])
time.sleep(1.5)
subprocess.Popen(["python", 'voice_wheres_my_body.py'])
time.sleep(0.4)
subprocess.Popen(["python", 'jaw_wheres_my_body.py'])
