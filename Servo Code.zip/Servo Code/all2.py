from __future__ import division
import time
import math
import random

import Adafruit_PCA9685

pwm = Adafruit_PCA9685.PCA9685(0x41)

# Configure min and max servo pulse lengths
servo_min = 150  # Min pulse length out of 4096 (150)
servo_max = 600  # Max pulse length out of 4096 (600)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

# Helper function to make setting a servo pulse width simpler.
def set_servo_pulse(channel, pulse):
    pulse_length = 1000000    # 1,000,000 us per second
    pulse_length //= 60       # 60 Hz
    print('{0}us per period'.format(pulse_length))
    pulse_length //= 4096     # 12 bits of resolution
    print('{0}us per bit'.format(pulse_length))
    pulse *= 1000
    pulse //= pulse_length
    pwm.set_pwm(channel, 0, pulse)

# Initialize servo channel for each AU

#---EYES--- (front Pi)
#8 and 9 are left right; 7 is up down; 6 and 5 are eyelids
#8 and 9: quickness 10; 310 to 390 pulse (neutral 350)
#7: quickness 10; 350 to 480 pulse (neutral 450)
#5 (right) and 6 (left): quickness 10; 375 to 550 (neutral 550)

servo1 = 8
servo2 = 7
servo3 = 6
servo4 = 5
servo5 = 9

#---NECK--- (front Pi)
servo6 = 15
servo7 = 14
servo8 = 13
servo9 = 12
servo10 = 11
servo11 = 10



#Time delay when rotating servo horn (seconds)
delay = 0.015

def eyesLeftRight():
    max_pulse = 390 # Defining max starting positions
    min_pulse = 310
    quickness = 5
    x = 0
    y = 0
    pos = 350
    pos2 = 375
    opposite = 0
    deg = 0
    rad = 0
    a = 0
    #600-150=450; 1 deg ~= 2.5 pulses; 0 deg ~= 150 and 180 deg ~= 600

    diff = (max_pulse - min_pulse)/2

    time_start = time.time()
    while True: 
        pwm.set_pwm(servo3,0,200)
        pwm.set_pwm(servo4,0,550)
        a = math.sin(rad)

        #print(a)
        pos = int((a*diff)+350)
        #print(pos)

        if(x == 0 and pos <= max_pulse):
            deg = deg + quickness
        else:
            x = 1
            
        if(x == 1 and pos >= min_pulse):
            deg = deg - quickness
        else:
            x = 0

        rad = (deg*3.1415)/180
        #print('y')

        pwm.set_pwm(servo1,0,pos)
        pwm.set_pwm(servo5,0,pos)
        time.sleep(0.005)

        time_end = time.time()

           
        if((time_end - time_start) > 5):
            pwm.set_pwm(servo1,0,370)
            pwm.set_pwm(servo5,0,360)
            break

def eyesUpDown():
    max_pulse = 480 # Defining max starting positions
    min_pulse = 350
    quickness = 3
    x = 0
    pos = 350
    pos2 = 375
    opposite = 0
    servo4_pos = 0
    servo2_5_pos = 0
    deg = 0
    rad = 0
    a = 0
    #600-150=450; 1 deg ~= 2.5 pulses; 0 deg ~= 150 and 180 deg ~= 600

    diff = (max_pulse - min_pulse)/2

    time_start = time.time()
    while True: 

        a = math.sin(rad)
        #print(a)
        pos = int((a*diff)+410)
        #print(pos)
        if(x == 0 and pos <= max_pulse):
            deg = deg + quickness
        else:
            x = 1
            
        if(x == 1 and pos >= min_pulse):
            deg = deg - quickness
        else:
            x = 0

        rad = (deg*3.1415)/180
        #print('y')
       
        pwm.set_pwm(servo2,0,pos)
        time.sleep(0.005)

        time_end = time.time()
##        if((time_end - time_start) > 2):
##            max_pulsee = 550 # Defining max starting positions
##            min_pulsee = 325
##            quicknesss = 5
##            xx = 0
##            poss = 350
##            oppositee = 0
##            degg = 0
##            radd = 0
##            aa = 0
##            #600-150=450; 1 deg ~= 2.5 pulses; 0 deg ~= 150 and 180 deg ~= 600
##
##            difff = (max_pulsee - min_pulsee) #range
##            #for eyelids: use diff = max_pulse - min_pulse b/c we are STARTING at the neutral position
##
##            time_startt = time.time()
##            #count = 0
##            while True: 
##                #count += 1
##                #print(count)
##                aa = abs(math.sin(radd))
##                #for eyelids: use a = abs(math.sin(rad))
##                #print(a)
##                poss = int((aa*difff)+325)
##                print(pos)
##                if(xx == 0 and poss <= max_pulsee):
##                    degg = degg + quicknesss
##                else:
##                    xx = 1
##                    
##                if(xx == 1 and poss >= min_pulsee):
##                    degg = degg - quicknesss
##                else:
##                    xx = 0
##
##                radd = (degg*3.1415)/180
##                #print('y')
##                
##
##                oppositee = 750 - poss # 600 - pos + 150 but rod is shorter, need to adjust
##
##                pwm.set_pwm(servo3,0,oppositee)
##                pwm.set_pwm(servo4,0,poss)
##                time.sleep(0.005)
##
##                time_endd = time.time()
##                
##                if((time_endd - time_startt) > 0.2):
##                    if(poss >= 549):
##                        pwm.set_pwm(servo3,0,200) #eyelids resting point 200
##                        pwm.set_pwm(servo4,0,550) #550 ...lower range should be 375 for servo4 and 520 for servo3
##                        break
                    
        
        if((time_end - time_start) > 5):
            pwm.set_pwm(servo2,0,400)
            break

def eyelids():
    max_pulse = 550 # Defining max starting positions
    min_pulse = 325
    quickness = 5
    x = 0
    pos = 350
    opposite = 0
    deg = 0
    rad = 0
    a = 0
    #600-150=450; 1 deg ~= 2.5 pulses; 0 deg ~= 150 and 180 deg ~= 600

    diff = (max_pulse - min_pulse) #range
    #for eyelids: use diff = max_pulse - min_pulse b/c we are STARTING at the neutral position

    time_start = time.time()
    #count = 0
    while True: 
        #count += 1
        #print(count)
        a = abs(math.sin(rad))
        #for eyelids: use a = abs(math.sin(rad))
        #print(a)
        pos = int((a*diff)+325)
        print(pos)
        if(x == 0 and pos <= max_pulse):
            deg = deg + quickness
        else:
            x = 1
            
        if(x == 1 and pos >= min_pulse):
            deg = deg - quickness
        else:
            x = 0

        rad = (deg*3.1415)/180
        #print('y')
        

        opposite = 750 - pos # 600 - pos + 150 but rod is shorter, need to adjust

        pwm.set_pwm(servo3,0,opposite)
        pwm.set_pwm(servo4,0,pos)
        time.sleep(0.005)

        time_end = time.time()
        if((time_end - time_start) > 0.2):
            if(pos >= 549):
                pwm.set_pwm(servo3,0,235) #eyelids resting point 200
                pwm.set_pwm(servo4,0,550) #550 ...lower range should be 375 for servo4 and 520 for servo3
                break

def neckNod():
    max_pulse = 475 # Defining max starting positions
    min_pulse = 275
    quickness = 2
    x = 0
    pos = 375
    opposite = 0
    servo9_pos = 0
    servo7_pos = 0
    servo10_pos = 0
    deg = 0
    rad = 0
    a = 0
    #600-150=450; 1 deg ~= 2.5 pulses; 0 deg ~= 150 and 180 deg ~= 600
   

    time_start = time.time()
    #time_end = 0

    diff = (max_pulse - min_pulse)/2


    while True: 

        a = math.sin(rad)
        #print(a)
        pos = int((a*diff)+375)
        #print(pos)
        if(x == 0 and pos <= max_pulse):
            deg = deg + quickness
        else:
            x = 1
            
        if(x == 1 and pos >= min_pulse):
            deg = deg - quickness
        else:
            x = 0

        rad = (deg*3.1415)/180
        #print('y')
        opposite = 750 - pos # 600 - pos + 150
        servo9_pos = pos + 75 # 30 degrees = 75 pulses
        servo7_pos = opposite 
        servo10_pos = opposite - 75
        pwm.set_pwm(servo6,0,pos)
        pwm.set_pwm(servo7,0,servo7_pos)
        pwm.set_pwm(servo9,0,servo9_pos)
        pwm.set_pwm(servo10,0,servo10_pos)
        time.sleep(0.001)

        time_end = time.time()
        if((time_end - time_start) > 5):
            time.sleep(0.5)
            pwm.set_pwm(servo6,0,375)
            pwm.set_pwm(servo7,0,375)
            pwm.set_pwm(servo8,0,375)
            pwm.set_pwm(servo9,0,375)
            pwm.set_pwm(servo10,0,375)
            pwm.set_pwm(servo11,0,375)
            time.sleep(0.5)
            break

def neckShake():
    max_pulse = 475 # Defining max starting positions
    min_pulse = 275
    quickness = 3.2
    x = 0
    pos = 375
    opposite = 0
    servo9_pos = 0
    servo7_10_pos = 0
    deg = 0
    rad = 0
    a = 0
    #600-150=450; 1 deg ~= 2.5 pulses; 0 deg ~= 150 and 180 deg ~= 600

    time_start = time.time()
    #time_end = 0

    diff = (max_pulse - min_pulse)/2

    while True: 

        a = math.sin(rad)
        #print(a)
        pos = int((a*diff)+375)
        #print(pos)
        if(x == 0 and pos <= max_pulse):
            deg = deg + quickness
        else:
            x = 1
            
        if(x == 1 and pos >= min_pulse):
            deg = deg - quickness
        else:
            x = 0

        rad = (deg*3.1415)/180
        
        pwm.set_pwm(servo6,0,pos)
        pwm.set_pwm(servo7,0,pos)
        pwm.set_pwm(servo8,0,pos)
        pwm.set_pwm(servo9,0,pos)
        pwm.set_pwm(servo10,0,pos)
        pwm.set_pwm(servo11,0,pos)
        time.sleep(.001)

        time_end = time.time()
        if((time_end - time_start) > 5):
            time.sleep(0.5)
            pwm.set_pwm(servo6,0,375)
            pwm.set_pwm(servo7,0,375)
            pwm.set_pwm(servo8,0,375)
            pwm.set_pwm(servo9,0,375)
            pwm.set_pwm(servo10,0,375)
            pwm.set_pwm(servo11,0,375)
            break

#Jaw left behaves as normal but jaw right has min and max flipped
def jaw_open_close():
    pwm = Adafruit_PCA9685.PCA9685()
    # Time delay when rotating servo horn (in seconds)
    #---JAW--- (back Pi)
    AU_delay = .001
    AU1_servo = 17
    AU2_servo = 17
    AU4_servo = 17
    AU6_servo = 0
    AU7_servo = 16
    AU9_servo = 17
    AU10_servo = 17
    AU11_servo = 17
    AU12_servo = 1
    AU23_servo = 17
    jaw_left = 15
    jaw_right = 14
    jaw_left_min_pulse = 210
    jaw_left_max_pulse = 370
    jaw_left_current_pulse = 210
    jaw_right_min_pulse = 210
    jaw_right_max_pulse = 370
    jaw_right_current_pulse = 370

    while(jaw_left_current_pulse < jaw_left_max_pulse or jaw_right_current_pulse > jaw_right_min_pulse):
        if(jaw_left_current_pulse < jaw_left_max_pulse):
            jaw_left_current_pulse += 1
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(AU_delay)

        if(jaw_right_current_pulse > jaw_right_min_pulse):
            jaw_right_current_pulse -= 1
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(AU_delay)

    time.sleep(1.5)

    while(jaw_left_current_pulse > jaw_left_min_pulse or jaw_right_current_pulse < jaw_right_max_pulse):
        if(jaw_left_current_pulse > jaw_left_min_pulse):
            jaw_left_current_pulse -= 1
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(AU_delay)

        if(jaw_right_current_pulse < jaw_right_max_pulse):
            jaw_right_current_pulse += 1
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(AU_delay)
        
    time.sleep(1.5)

#eyelids()
eyesLeftRight()
eyesUpDown()
neckNod()
neckShake()
jaw_open_close()
