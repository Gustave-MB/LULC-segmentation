from __future__ import division
import time
import math
import random

import Adafruit_PCA9685

pwm = Adafruit_PCA9685.PCA9685(0x41)

# Configure min and max servo pulse lengths
servo_min = 150  # Min pulse length out of 4096 (150)
servo_max = 600  # Max pulse length out of 4096 (600)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

# Helper function to make setting a servo pulse width simpler.
def set_servo_pulse(channel, pulse):
    pulse_length = 1000000    # 1,000,000 us per second
    pulse_length //= 60       # 60 Hz
    print('{0}us per period'.format(pulse_length))
    pulse_length //= 4096     # 12 bits of resolution
    print('{0}us per bit'.format(pulse_length))
    pulse *= 1000
    pulse //= pulse_length
    pwm.set_pwm(channel, 0, pulse)

# Initialize servo channel for each AU

#---EYES--- (front Pi)

#5 (right) and 6 (left): quickness 10; 375 to 550 (neutral 550)

servo3 = 6
servo4 = 5

#Time delay when rotating servo horn (seconds)
delay = 0.015

total_time_start = time.time()

def eyelids():
    max_pulse = 550 # Defining max starting positions
    min_pulse = 325
    quickness = 8
    x = 0
    pos = 350
    opposite = 0
    deg = 0
    rad = 0
    a = 0
    b = 0
    #600-150=450; 1 deg ~= 2.5 pulses; 0 deg ~= 150 and 180 deg ~= 600

    diff = (max_pulse - min_pulse) #range
    #for eyelids: use diff = max_pulse - min_pulse b/c we are STARTING at the neutral position

    time_start = time.time()
    #count = 0
    while True: 
        #count += 1
        #print(count)
        a = abs(math.sin(rad))
        #for eyelids: use a = abs(math.sin(rad))
        #print(a)
        pos = int((a*diff)+300)
        print(pos)
        if(x == 0 and pos <= max_pulse):
            deg = deg + quickness
        else:
            x = 1
            
        if(x == 1 and pos >= min_pulse):
            deg = deg - quickness
        else:
            x = 0

        rad = (deg*3.1415)/180
        #print('y')
        

        opposite = 750 - pos # 600 - pos + 150 but rod is shorter, need to adjust

        pwm.set_pwm(servo3,0,opposite)
        pwm.set_pwm(servo4,0,pos)
        time.sleep(0.005)

        time_end = time.time()
        if((time_end - time_start) > 0.2):
            if(pos >= 523):
                pwm.set_pwm(servo3,0,265) #eyelids resting point 235
                pwm.set_pwm(servo4,0,520) #550 ...lower range should be 375 for servo4 and 520 for servo3
                b = random.uniform(2,4)                
                time.sleep(b)
            if((time_end - total_time_start) > 30):
                break
            
eyelids()

