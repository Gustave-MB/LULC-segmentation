import subprocess
import time
import random
from time import sleep

subprocess.Popen(["python", 'expression_smile.py'])
time.sleep(6)

subprocess.Popen(["python", 'expression_sad.py'])
time.sleep(6)

subprocess.Popen(["python", 'expression_surprise.py'])
subprocess.Popen(["python", 'jaw_surprise.py'])
subprocess.Popen(["python", 'eyelids_surprise.py'])
subprocess.Popen(["python", 'voice_surprise.py'])
time.sleep(6)

subprocess.Popen(["python", 'expression_fear.py'])
subprocess.Popen(["python", 'jaw_fear.py'])
subprocess.Popen(["python", 'eyelids_fear.py'])
time.sleep(6)

subprocess.Popen(["python", 'expression_disgust.py'])
subprocess.Popen(["python", 'jaw_disgust.py'])
subprocess.Popen(["python", 'voice_disgust.py'])
time.sleep(6)

subprocess.Popen(["python", 'expression_anger.py'])
subprocess.Popen(["python", 'eyelids_anger.py'])





