from __future__ import division
import time
import math
import random

import Adafruit_PCA9685

pwm = Adafruit_PCA9685.PCA9685(0x41)

# Configure min and max servo pulse lengths
servo_min = 150  # Min pulse length out of 4096 (150)
servo_max = 600  # Max pulse length out of 4096 (600)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

# Helper function to make setting a servo pulse width simpler.
def set_servo_pulse(channel, pulse):
    pulse_length = 1000000    # 1,000,000 us per second
    pulse_length //= 60       # 60 Hz
    print('{0}us per period'.format(pulse_length))
    pulse_length //= 4096     # 12 bits of resolution
    print('{0}us per bit'.format(pulse_length))
    pulse *= 1000
    pulse //= pulse_length
    pwm.set_pwm(channel, 0, pulse)

# Initialize servo channel for each AU

#---EYES--- (front Pi)
#8 and 9 are left right; 7 is up down; 6 and 5 are eyelids
#8 and 9: quickness 10; 310 to 390 pulse (neutral 350)
#7: quickness 10; 350 to 480 pulse (neutral 450)
#5 (right) and 6 (left): quickness 10; 375 to 550 (neutral 550)

servo1 = 8
servo2 = 7
servo3 = 6
servo4 = 5
servo5 = 9

#---NECK--- (front Pi)
servo6 = 15
servo7 = 14
servo8 = 13
servo9 = 12
servo10 = 11
servo11 = 10



#Time delay when rotating servo horn (seconds)
delay = 0.015

def eyesLeftRight():
    pwm.set_pwm(servo1,0,370)
    pwm.set_pwm(servo5,0,360)

def eyesUpDown():
    pwm.set_pwm(servo2,0,400)

def eyelids():
    pwm.set_pwm(servo3,0,265) #eyelids prev resting point 235
    pwm.set_pwm(servo4,0,520) #prev: 550 ...lower range should be 375
   
def neck():
    pwm.set_pwm(servo6,0,375)
    pwm.set_pwm(servo7,0,375)
    pwm.set_pwm(servo8,0,375)
    pwm.set_pwm(servo9,0,375)
    pwm.set_pwm(servo10,0,375)
    pwm.set_pwm(servo11,0,375)

def jaw_open_close():
    pwm = Adafruit_PCA9685.PCA9685()
    #---JAW--- (back Pi)
    AU_delay = .001
    AU1_servo = 17
    AU2_servo = 17
    AU4_servo = 17
    AU6_servo = 0
    AU7_servo = 16
    AU9_servo = 17
    AU10_servo = 17
    AU11_servo = 17
    AU12_servo = 1
    AU23_servo = 17
    jaw_left = 15
    jaw_right = 14
    jaw_left_min_pulse = 210
    jaw_left_max_pulse = 370
    jaw_left_current_pulse = 210
    jaw_right_min_pulse = 210
    jaw_right_max_pulse = 370
    jaw_right_current_pulse = 370

eyelids()
eyesLeftRight()
eyesUpDown()
neck()
jaw_open_close()
