import subprocess
import time
from time import sleep

subprocess.Popen(["python", 'blink.py'])
subprocess.Popen(["python", 'all2.py'])


