from __future__ import division
import time
import math

import Adafruit_PCA9685

pwm = Adafruit_PCA9685.PCA9685()

# Configure min and max servo pulse lengths
servo_min = 150  # Min pulse length out of 4096 (150)
servo_max = 600  # Max pulse length out of 4096 (600)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

# Helper function to make setting a servo pulse width simpler.
def set_servo_pulse(channel, pulse):
    pulse_length = 1000000    # 1,000,000 us per second
    pulse_length //= 60       # 60 Hz
    print('{0}us per period'.format(pulse_length))
    pulse_length //= 4096     # 12 bits of resolution
    print('{0}us per bit'.format(pulse_length))
    pulse *= 1000
    pulse //= pulse_length
    pwm.set_pwm(channel, 0, pulse)

# Initialize servo channel for each AU
AU1_servo = 17
AU2_servo = 17
AU4_servo = 17
AU6_servo = 0
AU7_servo = 16
AU9_servo = 17
AU10_servo = 17
AU11_servo = 17
AU12_servo = 1
AU23_servo = 17
jaw_left = 15
jaw_right = 14

# Time delay when rotating servo horn (in seconds)
AU_delay = .001

def jaw_speak():
    jaw_left_min_pulse = 290
    jaw_left_max_pulse = 370
    jaw_left_current_pulse = 290
    jaw_right_min_pulse = 290
    jaw_right_max_pulse = 370
    jaw_right_current_pulse = 370

    while(jaw_left_current_pulse < jaw_left_max_pulse or jaw_right_current_pulse > jaw_right_min_pulse):
        if(jaw_left_current_pulse < jaw_left_max_pulse):
            jaw_left_current_pulse += 17
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(AU_delay)

        if(jaw_right_current_pulse > jaw_right_min_pulse):
            jaw_right_current_pulse -= 17
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(AU_delay)

    time.sleep(0.1)

    while(jaw_left_current_pulse > jaw_left_min_pulse or jaw_right_current_pulse < jaw_right_max_pulse):
        if(jaw_left_current_pulse > jaw_left_min_pulse):
            jaw_left_current_pulse -= 17
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(AU_delay)

        if(jaw_right_current_pulse < jaw_right_max_pulse):
            jaw_right_current_pulse += 17
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(AU_delay)
        
    time.sleep(0.1)

jaw_speak()
jaw_speak()
time.sleep(0.1)
jaw_speak()
jaw_speak()
jaw_speak()
jaw_speak()
jaw_speak()
jaw_speak()


