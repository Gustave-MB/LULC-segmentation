from __future__ import division
import time
import math

import Adafruit_PCA9685

pwm = Adafruit_PCA9685.PCA9685()

# Configure min and max servo pulse lengths
servo_min = 175  # Min pulse length out of 4096 (150)
servo_max = 400  # Max pulse length out of 4096 (600)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

# Initialize servo channel for each AU
AU1_servo = 11
AU2_servo = 13
AU4_servo = 12
AU6_servo = 9
AU7_servo = 10
AU9_servo = 6
AU10_servo = 7
AU11_servo = 8
AU12_servo = 5
AU15_servo = 3
AU16_servo = 2
AU20_servo = 4
jaw_left = 2
jaw_right = 3

# Time delay when rotating servo horn (in seconds)
AU_delay = .0001
jaw_delay = .001
expression_delay = 1.5

def fear():
    AU1_min_pulse = servo_min
    AU1_max_pulse = servo_max
    AU1_current_pulse = servo_min
    AU2_min_pulse = servo_min
    AU2_max_pulse = servo_max
    AU2_current_pulse = servo_min
    AU4_min_pulse = servo_min
    AU4_max_pulse = servo_max
    AU4_current_pulse = servo_min
    AU20_min_pulse = servo_min
    AU20_max_pulse = servo_max
    AU20_current_pulse = servo_min

    while(AU1_current_pulse < AU1_max_pulse or AU2_current_pulse < AU2_max_pulse or AU4_current_pulse < AU4_max_pulse or AU20_current_pulse < AU20_max_pulse):
        if(AU1_current_pulse < AU1_max_pulse):
            AU1_current_pulse += 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)

        if(AU2_current_pulse < AU2_max_pulse):
            AU2_current_pulse += 1
            pwm.set_pwm(AU2_servo,0,AU2_current_pulse)
        
        if(AU4_current_pulse < AU4_max_pulse):
            AU4_current_pulse += 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU20_current_pulse < AU20_max_pulse):
            AU20_current_pulse += 1
            pwm.set_pwm(AU20_servo,0,AU20_current_pulse)

        #time.sleep(AU_delay)
            
    time.sleep(expression_delay)

    while(AU1_current_pulse > AU1_min_pulse or AU2_current_pulse > AU2_min_pulse or AU4_current_pulse > AU4_min_pulse or AU20_current_pulse > AU20_min_pulse):
        if(AU1_current_pulse > AU1_min_pulse):
            AU1_current_pulse -= 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)

        if(AU2_current_pulse > AU2_min_pulse):
            AU2_current_pulse -= 1
            pwm.set_pwm(AU2_servo,0,AU2_current_pulse)
            
        if(AU4_current_pulse > AU4_min_pulse):
            AU4_current_pulse -= 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU20_current_pulse > AU20_min_pulse):
            AU20_current_pulse -= 1
            pwm.set_pwm(AU20_servo,0,AU20_current_pulse)
            
        #time.sleep(AU_delay)
        
    time.sleep(expression_delay)

fear()
