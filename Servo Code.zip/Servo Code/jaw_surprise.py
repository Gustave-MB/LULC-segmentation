from __future__ import division
import time
import math

import Adafruit_PCA9685

pwm = Adafruit_PCA9685.PCA9685()

# Configure min and max servo pulse lengths
servo_min = 175  # Min pulse length out of 4096 (150)
servo_max = 575  # Max pulse length out of 4096 (600)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

# Initialize servo channel for each AU
AU1_servo = 11
AU2_servo = 13
AU4_servo = 12
AU6_servo = 9
AU7_servo = 10
AU9_servo = 6
AU10_servo = 7
AU11_servo = 8
AU12_servo = 5
AU15_servo = 3
AU16_servo = 2
AU20_servo = 4
jaw_left = 2
jaw_right = 3

# Time delay when rotating servo horn (in seconds)
AU_delay = .0001
jaw_delay = .001
expression_delay = 1.5

#Jaw left behaves as normal but jaw right has min and max flipped
def jaw_open_close():
    pwm = Adafruit_PCA9685.PCA9685()
    # Time delay when rotating servo horn (in seconds)
    #---JAW--- (back Pi)
    AU_delay = .001
    AU1_servo = 17
    AU2_servo = 17
    AU4_servo = 17
    AU6_servo = 0
    AU7_servo = 16
    AU9_servo = 17
    AU10_servo = 17
    AU11_servo = 17
    AU12_servo = 1
    AU23_servo = 17
    jaw_left = 15
    jaw_right = 14
    jaw_min = 220
    jaw_max = 370
    jaw_left_min_pulse = jaw_min
    jaw_left_max_pulse = jaw_max
    jaw_left_current_pulse = jaw_min
    jaw_right_min_pulse = jaw_min
    jaw_right_max_pulse = jaw_max
    jaw_right_current_pulse = jaw_max

    while(jaw_left_current_pulse < jaw_left_max_pulse or jaw_right_current_pulse > jaw_right_min_pulse):
        if(jaw_left_current_pulse < jaw_left_max_pulse):
            jaw_left_current_pulse += 5
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(AU_delay)

        if(jaw_right_current_pulse > jaw_right_min_pulse):
            jaw_right_current_pulse -= 5
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(AU_delay)

    time.sleep(2)

    while(jaw_left_current_pulse > jaw_left_min_pulse or jaw_right_current_pulse < jaw_right_max_pulse):
        if(jaw_left_current_pulse > jaw_left_min_pulse):
            jaw_left_current_pulse -= 5
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(AU_delay)

        if(jaw_right_current_pulse < jaw_right_max_pulse):
            jaw_right_current_pulse += 5
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(AU_delay)
        
    time.sleep(1.5)

jaw_open_close()
