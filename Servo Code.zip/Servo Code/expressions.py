from __future__ import division
import time
import math

import Adafruit_PCA9685

pwm = Adafruit_PCA9685.PCA9685()

# Configure min and max servo pulse lengths
servo_min = 175  # Min pulse length out of 4096 (150)
servo_max = 500  # Max pulse length out of 4096 (600)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

# Initialize servo channel for each AU
AU1_servo = 11
AU2_servo = 13
AU4_servo = 12
AU6_servo = 9
AU7_servo = 10
AU9_servo = 6
AU10_servo = 7
AU11_servo = 8
AU12_servo = 5
AU15_servo = 3
AU16_servo = 2
AU20_servo = 4
#jaw_left = 2
#jaw_right = 3

# Time delay when rotating servo horn (in seconds)
AU_delay = .0001
jaw_delay = .001
expression_delay = 1.5

def smile():
    AU6_min_pulse = servo_min
    AU6_max_pulse = servo_max
    AU6_current_pulse = servo_min
    AU12_min_pulse = servo_min
    AU12_max_pulse = servo_max
    AU12_current_pulse = servo_min

    while(AU6_current_pulse < AU6_max_pulse or AU12_current_pulse < AU12_max_pulse):
        if(AU6_current_pulse < AU6_max_pulse):
            AU6_current_pulse += 1
            pwm.set_pwm(AU6_servo,0,AU6_current_pulse)

        if(AU12_current_pulse < AU12_max_pulse):
            AU12_current_pulse += 1
            pwm.set_pwm(AU12_servo,0,AU12_current_pulse)

        #time.sleep(AU_delay)
            
    time.sleep(expression_delay)

    while(AU6_current_pulse > AU6_min_pulse or AU12_current_pulse > AU12_min_pulse):
        if(AU6_current_pulse > AU6_min_pulse):
            AU6_current_pulse -= 1
            pwm.set_pwm(AU6_servo,0,AU6_current_pulse)

        if(AU12_current_pulse > AU12_min_pulse):
            AU12_current_pulse -= 1
            pwm.set_pwm(AU12_servo,0,AU12_current_pulse)
            
        #time.sleep(AU_delay)
        
    time.sleep(expression_delay)

def sad():
    AU1_min_pulse = servo_min
    AU1_max_pulse = servo_max
    AU1_current_pulse = servo_min
    AU4_min_pulse = servo_min
    AU4_max_pulse = servo_max
    AU4_current_pulse = servo_min
    AU11_min_pulse = servo_min
    AU11_max_pulse = servo_max
    AU11_current_pulse = servo_min
    AU15_min_pulse = 450
    AU15_max_pulse = 575
    AU15_current_pulse = 575

    while(AU1_current_pulse < AU1_max_pulse or AU4_current_pulse < AU4_max_pulse or AU11_current_pulse < AU11_max_pulse or AU15_current_pulse > AU15_min_pulse):
        if(AU1_current_pulse < AU1_max_pulse):
            AU1_current_pulse += 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)
        
        if(AU4_current_pulse < AU4_max_pulse):
            AU4_current_pulse += 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU11_current_pulse < AU11_max_pulse):
            AU11_current_pulse += 1
            pwm.set_pwm(AU11_servo,0,AU11_current_pulse)

        if(AU15_current_pulse > AU15_min_pulse):
            AU15_current_pulse -= 1
            pwm.set_pwm(AU15_servo,0,AU15_current_pulse)

        #time.sleep(AU_delay)
            
    time.sleep(expression_delay)

    while(AU1_current_pulse > AU1_min_pulse or AU4_current_pulse > AU4_min_pulse or AU11_current_pulse > AU11_min_pulse or AU15_current_pulse < AU15_max_pulse):
        if(AU1_current_pulse > AU1_min_pulse):
            AU1_current_pulse -= 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)
            
        if(AU4_current_pulse > AU4_min_pulse):
            AU4_current_pulse -= 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU11_current_pulse > AU11_min_pulse):
            AU11_current_pulse -= 1
            pwm.set_pwm(AU11_servo,0,AU11_current_pulse)

        if(AU15_current_pulse < AU15_max_pulse):
            AU15_current_pulse += 1
            pwm.set_pwm(AU15_servo,0,AU15_current_pulse)
            
        #time.sleep(AU_delay)
        
    time.sleep(expression_delay)

def fear():
    AU1_min_pulse = servo_min
    AU1_max_pulse = servo_max
    AU1_current_pulse = servo_min
    AU2_min_pulse = servo_min
    AU2_max_pulse = servo_max
    AU2_current_pulse = servo_min
    AU4_min_pulse = servo_min
    AU4_max_pulse = servo_max
    AU4_current_pulse = servo_min
    AU20_min_pulse = servo_min
    AU20_max_pulse = servo_max
    AU20_current_pulse = servo_min

    while(AU1_current_pulse < AU1_max_pulse or AU2_current_pulse < AU2_max_pulse or AU4_current_pulse < AU4_max_pulse or AU20_current_pulse < AU20_max_pulse):
        if(AU1_current_pulse < AU1_max_pulse):
            AU1_current_pulse += 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)

        if(AU2_current_pulse < AU2_max_pulse):
            AU2_current_pulse += 1
            pwm.set_pwm(AU2_servo,0,AU2_current_pulse)
        
        if(AU4_current_pulse < AU4_max_pulse):
            AU4_current_pulse += 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU20_current_pulse < AU20_max_pulse):
            AU20_current_pulse += 1
            pwm.set_pwm(AU20_servo,0,AU20_current_pulse)

        #time.sleep(AU_delay)
            
    time.sleep(expression_delay)

    while(AU1_current_pulse > AU1_min_pulse or AU2_current_pulse > AU2_min_pulse or AU4_current_pulse > AU4_min_pulse or AU20_current_pulse > AU20_min_pulse):
        if(AU1_current_pulse > AU1_min_pulse):
            AU1_current_pulse -= 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)

        if(AU2_current_pulse > AU2_min_pulse):
            AU2_current_pulse -= 1
            pwm.set_pwm(AU2_servo,0,AU2_current_pulse)
            
        if(AU4_current_pulse > AU4_min_pulse):
            AU4_current_pulse -= 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU20_current_pulse > AU20_min_pulse):
            AU20_current_pulse -= 1
            pwm.set_pwm(AU20_servo,0,AU20_current_pulse)
            
        #time.sleep(AU_delay)
        
    time.sleep(expression_delay)

def disgust():
    AU9_min_pulse = servo_min
    AU9_max_pulse = servo_max
    AU9_current_pulse = servo_min
    AU15_min_pulse = 450
    AU15_max_pulse = 575
    AU15_current_pulse = 575
    AU16_min_pulse = servo_min
    AU16_max_pulse = servo_max
    AU16_current_pulse = servo_min
    
    while(AU9_current_pulse < AU9_max_pulse or AU15_current_pulse > AU15_min_pulse or AU16_current_pulse < AU16_max_pulse):
        if(AU9_current_pulse < AU9_max_pulse):
            AU9_current_pulse += 1
            pwm.set_pwm(AU9_servo,0,AU9_current_pulse)

        if(AU15_current_pulse > AU15_min_pulse):
            AU15_current_pulse -= 1
            pwm.set_pwm(AU15_servo,0,AU15_current_pulse)

        if(AU16_current_pulse < AU16_max_pulse):
            AU16_current_pulse += 1
            pwm.set_pwm(AU16_servo,0,AU16_current_pulse)

        #time.sleep(AU_delay)
            
    time.sleep(expression_delay)

    while(AU9_current_pulse > AU9_min_pulse or AU15_current_pulse < AU15_max_pulse or AU16_current_pulse > AU16_min_pulse):
        if(AU9_current_pulse > AU9_min_pulse):
            AU9_current_pulse -= 1
            pwm.set_pwm(AU9_servo,0,AU9_current_pulse)

        if(AU15_current_pulse < AU15_max_pulse):
            AU15_current_pulse += 1
            pwm.set_pwm(AU15_servo,0,AU15_current_pulse)

        if(AU16_current_pulse > AU16_min_pulse):
            AU16_current_pulse -= 1
            pwm.set_pwm(AU16_servo,0,AU16_current_pulse)
            
        #time.sleep(AU_delay)
        
    time.sleep(expression_delay)

def anger():
    AU4_min_pulse = servo_min
    AU4_max_pulse = servo_max
    AU4_current_pulse = servo_min
    AU7_min_pulse = servo_min
    AU7_max_pulse = servo_max
    AU7_current_pulse = servo_min
    AU10_min_pulse = servo_min
    AU10_max_pulse = servo_max
    AU10_current_pulse = servo_min

    while(AU4_current_pulse < AU4_max_pulse or AU7_current_pulse < AU7_max_pulse or AU10_current_pulse < AU10_max_pulse):
        if(AU4_current_pulse < AU4_max_pulse):
            AU4_current_pulse += 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU7_current_pulse < AU7_max_pulse):
            AU7_current_pulse += 1
            pwm.set_pwm(AU7_servo,0,AU7_current_pulse)

        if(AU10_current_pulse < AU10_max_pulse):
            AU10_current_pulse += 1
            pwm.set_pwm(AU10_servo,0,AU10_current_pulse)

        #time.sleep(AU_delay)
            
    time.sleep(expression_delay)

    while(AU4_current_pulse > AU4_min_pulse or AU7_current_pulse > AU7_min_pulse or AU10_current_pulse > AU10_min_pulse):
        if(AU4_current_pulse > AU4_min_pulse):
            AU4_current_pulse -= 1
            pwm.set_pwm(AU4_servo,0,AU4_current_pulse)

        if(AU7_current_pulse > AU7_min_pulse):
            AU7_current_pulse -= 1
            pwm.set_pwm(AU7_servo,0,AU7_current_pulse)

        if(AU10_current_pulse > AU10_min_pulse):
            AU10_current_pulse -= 1
            pwm.set_pwm(AU10_servo,0,AU10_current_pulse)
            
        #time.sleep(AU_delay)
        
    time.sleep(expression_delay)

def surprise():
    AU1_min_pulse = servo_min
    AU1_max_pulse = servo_max
    AU1_current_pulse = servo_min
    AU2_min_pulse = servo_min
    AU2_max_pulse = servo_max
    AU2_current_pulse = servo_min

    while(AU1_current_pulse < AU1_max_pulse or AU2_current_pulse < AU2_max_pulse):
        if(AU1_current_pulse < AU1_max_pulse):
            AU1_current_pulse += 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)
            

        if(AU2_current_pulse < AU2_max_pulse):
            AU2_current_pulse += 1
            pwm.set_pwm(AU2_servo,0,AU2_current_pulse)

        #time.sleep(AU_delay)
            
    time.sleep(expression_delay)

    while(AU1_current_pulse > AU1_min_pulse or AU2_current_pulse > AU2_min_pulse):
        if(AU1_current_pulse > AU1_min_pulse):
            AU1_current_pulse -= 1
            pwm.set_pwm(AU1_servo,0,AU1_current_pulse)

        if(AU2_current_pulse > AU2_min_pulse):
            AU2_current_pulse -= 1
            pwm.set_pwm(AU2_servo,0,AU2_current_pulse)
            
        #time.sleep(AU_delay)
        
    time.sleep(expression_delay)

#Jaw left behaves as normal but jaw right has min and max flipped
def jaw_open_close():
    jaw_left_min_pulse = 340
    jaw_left_max_pulse = 420
    jaw_left_current_pulse = 340
    jaw_right_min_pulse = 280
    jaw_right_max_pulse = 360
    jaw_right_current_pulse = 360

    while(jaw_left_current_pulse < jaw_left_max_pulse or jaw_right_current_pulse > jaw_right_min_pulse):
        if(jaw_left_current_pulse < jaw_left_max_pulse):
            jaw_left_current_pulse += 1
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(jaw_delay)

        if(jaw_right_current_pulse > jaw_right_min_pulse):
            jaw_right_current_pulse -= 1
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(jaw_delay)

    time.sleep(expression_delay)

    while(jaw_left_current_pulse > jaw_left_min_pulse or jaw_right_current_pulse < jaw_right_max_pulse):
        if(jaw_left_current_pulse > jaw_left_min_pulse):
            jaw_left_current_pulse -= 1
            pwm.set_pwm(jaw_left,0,jaw_left_current_pulse)
            time.sleep(jaw_delay)

        if(jaw_right_current_pulse < jaw_right_max_pulse):
            jaw_right_current_pulse += 1
            pwm.set_pwm(jaw_right,0,jaw_right_current_pulse)
            time.sleep(jaw_delay)
        
    time.sleep(expression_delay)

smile()
#sad()
#fear()
#disgust()
#anger()
#surprise()
#jaw_open_close()







